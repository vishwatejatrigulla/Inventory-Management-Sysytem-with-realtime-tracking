const CollectionModel = require("../models/CollectionModel.js");

Date.prototype.getWeek = function() {
  const date = new Date(this.getTime());
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
  const week1 = new Date(date.getFullYear(), 0, 4);
  return 1 + Math.round(((date - week1) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
};

exports.salesOverTime = async (req, res) => {
  try {
    // Retrieve all collections along with their associated items
    const allCollections = await CollectionModel.find().populate('items');
    // console.log(allCollections)
    // Initialize variables to store sales data
    const dailySales = {};
    const weeklySales = {};
    const monthlySales = {};

    // Iterate through each item to calculate sales over time
    allCollections.forEach(collection => {
      // console.log(collection.items)
      collection.items.forEach(item => {
        if (item.sold) {
          const soldDate = new Date(item.soldDate);
          
          // Calculate daily sales
          const dailyKey = soldDate.toISOString().slice(0, 10);
          dailySales[dailyKey] = dailySales[dailyKey] ? dailySales[dailyKey] + 1 : 1;

          // Calculate weekly sales
          const weekNumber = soldDate.getWeek(); // Custom function to get week number
          weeklySales[weekNumber] = weeklySales[weekNumber] ? weeklySales[weekNumber] + 1 : 1;

          // Calculate monthly sales
          const monthName = soldDate.toLocaleString('default', { month: 'long' });
          monthlySales[monthName] = monthlySales[monthName] ? monthlySales[monthName] + 1 : 1;
        }
      });
    });

    // Prepare the response object
    // console.log(dailySales)
    // console.log(dailySale)
    const salesData = {
      daily_sales: Object.entries(dailySales).map(([date, total_sales]) => ({ date, total_sales })),
      weekly_sales: Object.entries(weeklySales).map(([week, total_sales]) => ({ week, total_sales })),
      monthly_sales: Object.entries(monthlySales).map(([month, total_sales]) => ({ month, total_sales })),
    };
    // console.log("sales data : ",salesData)
    // Send the response back to the client
    res.status(200).send(salesData);
  } catch (error) {
    res.status(500).send({
      message: "Error getting sales data over time",
      success: false,
      error,
    });
  }
};

exports.topSellingItems = async (req, res) => {
  try {
    // Retrieve all collections along with their associated items
    const allCollections = await CollectionModel.find().populate('items');
    
    // Initialize an object to store item sales data
    const itemSalesData = {};
    
    // Iterate through each item to calculate total quantity sold or revenue generated
    allCollections.forEach(collection => {
      collection.items.forEach(item => {
        if (item.sold) {
          if (!itemSalesData[item._id]) {
            itemSalesData[item._id] = {
              name: item.name,
              total_quantity_sold: 0,
              total_revenue_generated: 0,
              image: item.image,
              brand: item.brand
            };
            // console.log(itemSalesData[item._id]);
          }
          // Update total quantity sold
          itemSalesData[item._id].total_quantity_sold += 1;
          // Update total revenue generated
          itemSalesData[item._id].total_revenue_generated += item.price;
        }
      });
    });

    // Sort items based on total quantity sold or revenue generated in descending order
    const sortedItems = Object.values(itemSalesData).sort((a, b) => b.total_quantity_sold - a.total_quantity_sold);
    console.log("sorted ,",sortedItems)
    // Extract top-selling items
    const topSellingItems = sortedItems.slice(0, 10); // Adjust the number to get top N items
  
    // Prepare the response object
    const response = {
      top_selling_items: topSellingItems,
    };

    // Send the response back to the client
    res.status(200).json(response);
  } catch (error) {
    console.error('Error fetching top selling items:', error);
    res.status(500).json({
      message: "Error getting top selling items",
      success: false,
      error,
    });
  }
};

exports.salesByCollection = async (req, res) => {
  try {
    // Retrieve all collections along with their associated items
    const allCollections = await CollectionModel.find().populate('items');

    // Initialize an object to store collection sales data
    const collectionSalesData = {};

    // Iterate through each collection and its items to calculate total quantity sold and revenue generated
    allCollections.forEach(collection => {
      const collectionId = collection._id;
      const collectionName = collection.title;
      const totalItems = collection.items.length;
      let totalRevenueGenerated = 0;
      let totalQuantitySold = 0;
      
      collection.items.forEach(item => {
        if (item.sold) {
          // Update total quantity sold
          totalQuantitySold++;
          // Update total revenue generated
          totalRevenueGenerated += item.price;
        }
      });

      // Store sales data for the collection
      collectionSalesData[collectionId] = {
        collectionName,
        totalItems,
        totalQuantitySold,
        totalRevenueGenerated,
        image:collection.image,
      };
    });

    // Find the best-selling collection based on total revenue generated
    let bestSellingCollection = null;
    let maxRevenue = 0;
    Object.entries(collectionSalesData).forEach(([collectionId, salesData]) => {
      if (salesData.totalRevenueGenerated > maxRevenue) {
        bestSellingCollection = salesData.collectionName;
        maxRevenue = salesData.totalRevenueGenerated;
      }
    });

    // Prepare the response object with sales data grouped by collection
    const response = {
      collectionSalesData,
      bestSellingCollection,
      maxRevenue,
    };

    // Send the response back to the client
    res.status(200).send(response);
  } catch (error) {
    res.status(500).send({
      message: "Error getting sales by collection",
      success: false,
      error,
    });
  }
};

