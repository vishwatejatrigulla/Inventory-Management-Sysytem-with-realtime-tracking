const ItemModel = require("../models/ItemsModel.js");
const CollectionModel = require("../models/CollectionModel.js");
const UserModel  = require('../models/Usermodel.js')

exports.createItem = async (req, res) => {
  try {
    const {
      name,
      price,
      image,
      brand,
      category,
      description,
      stockQuantity,
      id_collection,
      
    } = req.body;

    console.log(req.body);
    const item = new ItemModel({...req.body,collection:id_collection});

    await item.save();
    const collection = await CollectionModel.findById(id_collection);
    collection.items.push(item._id);
    await collection.save();
    res.status(200).send({
      message: "Succesfully created",
      success: true,
      item,
    });
  } catch (error) {
    res.status(500).send({
      message: "Error creating Item",
      success: false,
      error,
    });
  }
};
exports.createTempItem = async (req, res) => {
  try {
    const {
      name,
      price,
      image,
      brand,
      category,
      description,
      stockQuantity,
      id_collection,
      userId
    } = req.body;

    console.log(req.body);
    const currentDate = new Date();

// Get the current month and year
    let currentMonth = currentDate.getMonth();
    let currentYear = currentDate.getFullYear();
    currentMonth++;
    currentMonth++;
    const nextMonthDate = new Date(currentYear, currentMonth);
    const item = new ItemModel({...req.body,collection:id_collection,sold:true,owner:userId,soldDate:nextMonthDate});

    await item.save();
    const collection = await CollectionModel.findById(id_collection);
    collection.items.push(item._id);
    await collection.save();
    res.status(200).send({
      message: "Succesfully created",
      success: true,
      item,
    });
  } catch (error) {
    res.status(500).send({
      message: "Error creating Item",
      success: false,
      error,
    });
  }
};

exports.buyItem = async (req, res) => {
  try {
    console.log("charal ",req.body)
    const { userId, itemId } = req.body;
    const user = await UserModel.findById(userId);
    user.itemsOwned.push(itemId);
    await user.save();

    const item = await ItemModel.findById(itemId)
    item.owner=userId;
    item.sold=true;
    item.soldDate = new Date();

    await item.save();

    res.status(200).send({
      message: "Item Bought Successfully!",
      success: true,
      user,
    });
  } catch (error) {
    res.status(500).send({
      message: "Error Buying Item",
      success: false,
      error,
    });
  }
};


exports.deleteItem = async (req, res) => {
  try {
    await ItemModel.findByIdAndDelete(req.params.id);
    return res.status(200).send({
      message: "Item deleted succesfully",
      success: true,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      message: "Error while deleting",
      success: false,
      error,
    });
  }
};
