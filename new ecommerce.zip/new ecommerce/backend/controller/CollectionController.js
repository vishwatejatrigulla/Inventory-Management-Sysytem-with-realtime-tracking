const CollectionModel = require("../models/CollectionModel.js");

exports.createCollection = async (req, res) => {
  try {
    const newCollection = new CollectionModel(req.body);
    await newCollection.save();
    res.status(200).send({
      message: "Collection created sucessfully",
      success: true,
      newCollection,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      message: "Error in creating collection",
      success: false,
      error,
    });
  }
};

exports.getCollection = async (req, res) => {
  try {
    console.log(req.params.quizId);
    const collection = await CollectionModel.findById(
      req.params.collectionId
    ).populate("items");
    res.status(200).send({
      message: "Collection fetched succesfully",
      success: true,
      collection,
    });
  } catch (error) {
    res.status(500).send({
      message: "Error in getting collection",
      success: false,
      error,
    });
  }
};

exports.getAllCollections = async (req, res) => {
  try {
    console.log("hello")
    const allCollection = await CollectionModel.find().populate('items');
    res.status(200).send({
      message: "Collection fetched successfully",
      success: true,
      allCollection,
    });
  } catch (error) {
    res.status(500).send({
      message: "Error getting Collections",
      success: false,
      error,
    });
  }
};

exports.deleteCollection = async (req, res) => {
  try {
    await CollectionModel.findByIdAndDelete(req.params.id);
    return res.status(200).send({
      message: "Collection deleted succesfully",
      success: true,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      message: "Error while deleting",
      success: false,
      error,
    });
  }
};
