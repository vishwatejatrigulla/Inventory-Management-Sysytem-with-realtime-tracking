const express = require("express");
const connectDB = require("./config/db.js");
const cors = require("cors");
const bodyParser = require("body-parser");

const UserRoutes = require("./routes/UserRoutes.js");
const CollectionRoute = require("./routes/CollectionRoute.js");
const ItemRoute = require("./routes/ItemRoute.js");
const analyticsRoute = require("./routes/AnalyticsRoutes.js");

connectDB();
const app = express();
app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use("/api/v1/user", UserRoutes);

app.use("/api/v1/collection", CollectionRoute);
app.use("/api/v1/item", ItemRoute);
app.use("/api/v1/analytics", analyticsRoute);

app.listen(3001, () => {
  console.log("Server Working");
});
