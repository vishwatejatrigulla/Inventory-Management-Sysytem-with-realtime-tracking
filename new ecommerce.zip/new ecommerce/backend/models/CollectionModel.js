const mongoose = require("mongoose");

const collectionSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  image: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    
  },
  items: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Item",
    },
  ],
  adminID: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Admin",
  },
});

const Collection = mongoose.model("Collection", collectionSchema);
module.exports = Collection;
