const express = require("express");
const router = express.Router();
const itemController = require("../controller/ItemController.js");

router.post("/createItem", itemController.createItem);
router.post("/create-temp-item", itemController.createTempItem);
router.post("/deleteItem/:id", itemController.deleteItem);
router.post("/buy-item", itemController.buyItem);

module.exports = router;
