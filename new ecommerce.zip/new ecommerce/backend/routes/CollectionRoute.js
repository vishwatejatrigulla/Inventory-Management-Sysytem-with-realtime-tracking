const express = require("express");
const router = express.Router();

const collectionController = require("../controller/CollectionController");

router.post("/createCollection", collectionController.createCollection);
router.get("/getallCollection", collectionController.getAllCollections);
router.get("/:collectionId", collectionController.getCollection);
router.post("/deleteCollection/:id", collectionController.deleteCollection);

module.exports = router;
