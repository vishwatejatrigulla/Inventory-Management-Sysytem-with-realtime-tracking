const express = require("express");
const router = express.Router();

const analyticsController = require("../controller/AnalyticsController");

router.get("/sales-over-time", analyticsController.salesOverTime);
router.get("/top-selling-items", analyticsController.topSellingItems);
router.get("/sales-by-collections", analyticsController.salesByCollection);


module.exports = router;
