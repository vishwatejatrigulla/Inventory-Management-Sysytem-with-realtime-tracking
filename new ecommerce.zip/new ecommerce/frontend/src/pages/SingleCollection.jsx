import React from 'react'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import Items from '../components/items'
import AddButton from '../components/AddButton'
import ItemModal from '../components/ItemModal'; // Import your modal component here
import { useState } from 'react'
import { useLocation } from 'react-router-dom'
import { useParams } from 'react-router-dom';
import useFetch from '../hooks/useFetch'

function SingleCollection() {

  const user = JSON.parse(localStorage.getItem('user'));
  const userId = user._id;
  const { id } = useParams();
  const { data, loading, error } = useFetch(`http://localhost:3001/api/v1/collection/${id}`);
  console.log(id)
  console.log(data)
  const [isModalOpen, setIsModalOpen] = useState(false);

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  return (
    <div>
    <Navbar />
    <div className="container mx-auto flex flex-col">
      <div className='px-12 w-full my-8 flex justify-center items-center '>
        {user.role=='admin' && <div className='w-full flex justify-between items-center'>
          <h1 className='text-xl font-semibold'>Browse Items in Collection : <span className='text-3xl font-bol'>{data?.collection?.title}</span> </h1>
          <div>
          <AddButton text={"Add an Item"}  onClick={toggleModal}/>
          </div>
        </div>}
      
      </div>
      <div className="px-12 w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
      {loading? "Loading":(
        <>
            {data.collection.items.map((item) => {

              if(user.role=='user' && (!item.sold)){
                return <Items title={item.name} id={item._id} key={item._id} content={item.description} image={item.image} brand={item.brand} price={item.price} stockQuantity={item.stockQuantity}/>
              }
              else if(user.role=='admin'){
                return <Items title={item.name} id={item._id} key={item._id} content={item.description} image={item.image} sold={item.sold} brand={item.brand} price={item.price} stockQuantity={item.stockQuantity}/>
              }
      
              })}
            </> 
            )
          } 

        {/* Add more cards as needed */}
      </div>
      
    </div>
    
    
    {/* Render the modal component */}
    {isModalOpen && <ItemModal onClose={toggleModal} id={id}/>}
  </div>
  )
}

export default SingleCollection