import React from 'react'
import img from '../assets/home-bg.jpg'
import Navbar from '../components/Navbar'
import { Link } from 'react-router-dom';
const Home = () => {
  const user = JSON.parse(localStorage.getItem('user'));
  const userId = user._id;
  return (
    <div className='h-screen w-screen relative'>
      {/* Background Image */}
      <img src={img} alt="" className='absolute h-full w-full object-cover top-0 left-0 brightness-50'/>

      {/* Navbar */}
      <Navbar/>

      {/* Main Content */}
      <div className='absolute z-50 left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-center text-white bg-[rgba(255,255,255,0.28)] backdrop-blur-md p-8 rounded-xl'>
        <h1 className='text-4xl font-bold mb-8'>Welcome to Inventory Management Dashboard</h1>
        <p className='text-lg mb-4'>Manage your inventory efficiently and gain insights with our powerful data analytics tools.</p>
        <div className='flex justify-center items-center'>
          <Link to='/collections'>
            <button className='bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg mr-4'>View Inventory</button>
          </Link>
          {
            user.role=='admin' && 
            <Link to='/analytics'>
              <button className='bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-lg'>Analytics</button>
            </Link>
          }
        </div>
      </div>
    </div>
  );
};

export default Home