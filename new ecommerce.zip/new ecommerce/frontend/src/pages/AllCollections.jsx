import React from 'react'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import Card from '../components/Card'
import AddButton from '../components/AddButton'
import useFetch from '../hooks/useFetch'
import Modal from '../components/Modal'; // Import your modal component here
import { useState ,useEffect } from 'react'
import axios from 'axios';



function AllCollections() {
  const user = JSON.parse(localStorage.getItem('user'));
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { data, loading, error } = useFetch('http://localhost:3001/api/v1/collection/getallCollection');
  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };
 console.log(data.allCollection)
 
  return (
    <div>
    <Navbar />
    <div className="container mx-auto flex flex-col">
      <div className='px-12 w-full my-8 flex justify-center items-center '>
        {user.role=='admin' &&  <div className='w-full flex justify-between items-center'>
          <h1 className='text-3xl font-bold'>Browse Your Collections</h1>
          <div>
          <AddButton text={"Add a Collection"}  onClick={toggleModal}/>
          </div>
        </div>}
      
      </div>
      <div className="px-12 w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {loading? "Loading":(
        <>
            {data.allCollection.map((item) => {
              return <Card title={item.title} id={item._id} key={item._id} content={item.description} image={item.image} />
              })}
            </> 
            )
          } 
      </div>
      
    </div>
    {/* Render the modal component */}
    {isModalOpen && <Modal onClose={toggleModal} />}
  </div>
  )
}

export default AllCollections