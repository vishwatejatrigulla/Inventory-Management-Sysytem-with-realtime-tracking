import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import SalesByTime from '../components/SalesByTime';
import TopSellers from '../components/TopSellers';
import SalesByCollections from '../components/SalesByCollections';


const Analytics = () => {
  const [currentIndex, setCurrentIndex] = useState(2);
  
  return (
    <div>
      <Navbar />

      <div className='w-full px-12 h-full'>

        <div className='flex items-center gap-8 w-full mt-6'>
          <div className={`${currentIndex === 0 ? 'bg-blue-500 text-white' : 'bg-zinc-300 text-black hover:bg-zinc-400'} px-6 py-2 text-lg cursor-pointer rounded-xl`} onClick={() => { setCurrentIndex(0) }}>Sales by Time</div>
          <div className={`${currentIndex === 1 ? 'bg-blue-500 text-white' : 'bg-zinc-300 text-black hover:bg-zinc-400'} px-6 py-2 text-lg cursor-pointer rounded-xl`} onClick={() => { setCurrentIndex(1) }}>Top Sellers</div>
          <div className={`${currentIndex === 2 ? 'bg-blue-500 text-white' : 'bg-zinc-300 text-black hover:bg-zinc-400'} px-6 py-2 text-lg cursor-pointer rounded-xl`} onClick={() => { setCurrentIndex(2) }}>Sales by Collection</div>
        </div>

        {currentIndex==0 && <SalesByTime/> }
        {currentIndex==1 && <TopSellers/> }
        {currentIndex==2 && <SalesByCollections/> }
      </div>
    </div>
  );
}

export default Analytics;
