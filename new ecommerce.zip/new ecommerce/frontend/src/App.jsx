import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";
import Home from "./pages/Home";

import AllCollections from "./pages/AllCollections";
import SingleCollection from "./pages/SingleCollection";
import Login from "./pages/Login";
import SignUp from "./pages/SignUp";
import Analytics from "./pages/Analytics";




function App() {
  return (
    <BrowserRouter>
      <Routes>
      <Route path="/home" element={<Home/>}/>
      <Route path="/collections" element={<AllCollections/>}/>
      <Route exact path="/collections/:id" element={<SingleCollection/>} />

      <Route path='/' element={<Login/>}/>
      <Route path='/register' element={<SignUp/>}/>
      <Route path='/analytics' element={<Analytics/>}/>
      
      </Routes>
    </BrowserRouter>
  );
}

export default App;
