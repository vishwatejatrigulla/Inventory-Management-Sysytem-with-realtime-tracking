import React,{useState,useEffect} from 'react'
import Chart from 'chart.js/auto';
const SalesByTime = () => {

    const host = 'http://localhost:3001';

    useEffect(() => {
      getSalesByTime();
    }, []);
  
    const getSalesByTime = async () => {
      try {
        const res = await fetch(`${host}/api/v1/analytics/sales-over-time`);
        const data = await res.json();
        
        console.log(data);
  
        // Extract data for the line chart
        const dailyLabels = data.daily_sales.map(item => item.date);
        const dailySalesData = data.daily_sales.map(item => item.total_sales);
        
        // Extract data for the line chart
        const weeklyLabels = data.weekly_sales.map(item => item.week);
        const weeklySalesData = data.weekly_sales.map(item => item.total_sales);
        
        // Extract data for the line chart
        const monthlyLabels = data.monthly_sales.map(item => item.month);
        const monthlySalesData = data.monthly_sales.map(item => item.total_sales);
  
        // Create the line chart for daily sales
        const dailyCtx = document.getElementById('dailySalesChart').getContext('2d');
        new Chart(dailyCtx, {
          type: 'line',
          data: {
            labels: dailyLabels,
            datasets: [{
              label: 'Daily Sales',
              data: dailySalesData,
              borderColor: 'rgba(255, 99, 132, 1)',
              borderWidth: 2,
              fill: false,
              tension: 0.1,
            }]
          },
          options: {
            scales: {
              y: {
                beginAtZero: true
              }
            }
          }
        });
  
        // Create the line chart for weekly sales
        const weeklyCtx = document.getElementById('weeklySalesChart').getContext('2d');
        new Chart(weeklyCtx, {
          type: 'line',
          data: {
            labels: weeklyLabels,
            datasets: [{
              label: 'Weekly Sales',
              data: weeklySalesData,
              borderColor: 'rgba(54, 162, 235, 1)',
              borderWidth: 2,
              fill: false,
              tension: 0.1,
            }]
          },
          options: {
            scales: {
              y: {
                beginAtZero: true
              }
            }
          }
        });
  
        // Create the line chart for monthly sales
        const monthlyCtx = document.getElementById('monthlySalesChart').getContext('2d');
        new Chart(monthlyCtx, {
          type: 'line',
          data: {
            labels: monthlyLabels,
            datasets: [{
              label: 'Monthly Sales',
              data: monthlySalesData,
              borderColor: 'rgba(75, 192, 192, 1)',
              borderWidth: 2,
              fill: false,
              tension: 0.1,
            }]
          },
          options: {
            scales: {
              y: {
                beginAtZero: true
              }
            }
          }
        });
  
        // Draw conclusions
        drawConclusions(data);
      } catch (error) {
        console.error('Error fetching sales by time:', error);
      }
    };
  
    const drawConclusions = (data) => {
      // Get the most profitable month
      const mostProfitableMonth = data.monthly_sales.reduce((prev, current) => (prev.total_sales > current.total_sales) ? prev : current);
  
      // Get average monthly sales
      const totalMonthlySales = data.monthly_sales.reduce((acc, curr) => acc + curr.total_sales, 0);
      const averageMonthlySales = totalMonthlySales / data.monthly_sales.length;
  
      // Draw conclusions on the page
      const conclusionsContainer = document.getElementById('conclusions');
      conclusionsContainer.innerHTML = `
        <div class="font-semibold text-lg mb-4">Conclusions:</div>
        <div class="mb-2">- The most profitable month is ${mostProfitableMonth.month} with ${mostProfitableMonth.total_sales} total sales.</div>
        <div class="mb-2">- The average monthly sales is ${Math.round(averageMonthlySales)}.</div>
        <div class="mb-2">- Analyze weekly and daily sales patterns to identify potential marketing opportunities or customer behavior trends.</div>
        <div class="mb-2">- Consider seasonal variations in sales to optimize inventory management and marketing strategies.</div>
        <div class="mb-2">- Identify top-selling items and categories to prioritize inventory and marketing efforts.</div>
      `;
    };
  
  return (
    <div className='h-full w-full'>
        <div className='p-6 rounded-xl bg-white shadow-xl mt-8'>
          <canvas id="dailySalesChart" width="800" height="400"></canvas>
        </div>
        <div className='p-6 rounded-xl bg-white shadow-xl mt-8'>
          <canvas id="weeklySalesChart" width="800" height="400"></canvas>
        </div>
        <div className='p-6 rounded-xl bg-white shadow-xl mt-8'>
          <canvas id="monthlySalesChart" width="800" height="400"></canvas>
        </div>

        <div className='mb-8 p-6 rounded-xl bg-white shadow-xl mt-8' id="conclusions">
          {/* Conclusions will be dynamically added here */}
        </div>
    </div>
  )
}

export default SalesByTime