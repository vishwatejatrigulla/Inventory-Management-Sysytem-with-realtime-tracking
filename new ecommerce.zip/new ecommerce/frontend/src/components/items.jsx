import React from 'react';

const Items = ({ title, content, image , price , brand , stockQuantity , id, sold}) => {

  const host="http://localhost:3001"
  const user = JSON.parse(localStorage.getItem('user'));
  const userId = user._id;

  const handlebuyNow = async()=>{
    console.log(user)
    const res = await fetch(`${host}/api/v1/item/buy-item`,{
      method:"POST",
      body:JSON.stringify({
        userId:userId,
        itemId:id
      }),
      headers:{
        'Content-Type':'application/json'
      }
    });

    const data = await res.json();
    console.log(data);
    alert(data.message);
  }
 return (
    <div className="bg-white shadow-xl border border-zinc-300 rounded-lg p-4 flex flex-col relative">
      {sold && <div className='w-fit absolute top-4 right-4 rounded-xl bg-green-500 text-white font-semibold px-6 py-2 text-sm'>
        SOLD
      </div>}
      {image && (
        <div className="relative h-48 w-full overflow-hidden rounded-lg mb-4">
          <img src={image} alt={title} className="absolute inset-0 w-full h-full object-contain" />
        </div>
      )}
      <h2 className="text-lg font-semibold mb-2">{title}</h2>
      <p className="text-gray-700">{content}</p>
      <p className="text-gray-700">Price: {price}</p>
      <p className="text-gray-700">Brand: {brand}</p>
      <p className="text-gray-700">Stock Qunatity: {stockQuantity}</p>
      { user.role=='user'? <button className='text-white bg-green-500 hover:bg-green-400 cursor-pointer p-2 rounded-xl mt-5 font-bold'
      onClick={()=>handlebuyNow(id)}
      >Buy now</button>:''}
      
    </div>
 );
};

export default Items;
