// Navbar.js
import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {

  const user = JSON.parse(localStorage.getItem('user'));
  const userId = user._id;

  return (
    <nav className="bg-blue-600 px-12 p-4 h-16 z-50 relative">
      <div className="container mx-auto">
        <div className="flex items-center justify-between">
          {user.role=='admin'?  <div className="text-white font-bold text-xl">Admin Panel</div> :
            <div className="text-white font-bold text-xl">User Panel</div>
          }
          <div className='flex items-center gap-8'>
            <Link to='/home' className=' text-white'>Home</Link>
            <Link to='/collections' className=' text-white'>Collections</Link>
            {
              user.role=='admin' && <Link to='/analytics' className='text-white'>Analytics</Link>
            }
            <Link to='/' className=' text-white'>Logout</Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
