import React, { useState } from 'react';
import axios from 'axios'
const Modal = ({ onClose }) => {
  const [image, setImage] = useState(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = () => {
      if (reader.readyState === 2) {
        setImage(reader.result);
      }
    };

    if (file) {
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Upload file to Cloudinary
      const formData = new FormData();
      formData.append("file", image);
      formData.append("upload_preset", "upload");

      const uploadRes = await axios.post(
        "https://api.cloudinary.com/v1_1/dh6zjine0/image/upload",
        formData
      );
      
      // Get the file URL from Cloudinary response
      const fileUrl = uploadRes.data.url;

      // Create FormData object and append form data
   // Add file URL

      // Make POST request to backend
      const response = await axios.post("http://localhost:3001/api/v1/collection/createCollection",
      {
        title,
        description,
        image:fileUrl,
        adminId:"66096945034acbd1be8f61d7",
       

      });
      window.location.reload();
      alert("Collection added successfully");
      // Display success message or handle response as needed
      console.log("Collection created successfully:", response.data);

      // Close the modal
      setOpen(false);
    } catch (error) {
      console.error("Error creating agreement:", error);
      // Handle error
    }
  };

  return (
    <div className="fixed top-0 left-0 w-full h-full flex justify-center items-center bg-gray-500 bg-opacity-50">
      <div className="bg-white p-8 rounded-lg shadow-lg ">
        
        <div className="mb-4 flex justify-center flex-col w-full items-center">
        <h2 className="text-2xl font-semibold mb-4">Add New Collection</h2>
          {image ? (
            <img src={image} alt="Uploaded" className="rounded-lg w-64 h-40 object-cover" />
          ) : (
            <img
              src="https://icon-library.com/images/no-image-icon/no-image-icon-0.jpg"
              alt="Uploaded"
              className="rounded-lg w-64 h-40 object-cover"
            />
          )}
          
        </div>
        <input
  type="file"
  accept="image/*"
  onChange={handleImageChange}
  className="mt-2 mb-4 appearance-none w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500  flex items-center justify-center cursor-pointer"
/>
        <input
          type="text"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="mb-4 px-4 py-2 w-full border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
        />
        <textarea
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="mb-4 px-4 py-2 w-full h-24 border border-gray-300 rounded-lg resize-none focus:outline-none focus:border-blue-500"
        />
        <div className="flex justify-end">
          <button className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 mr-2 focus:outline-none" onClick={onClose}>
            Close
          </button>
          <button className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 focus:outline-none" onClick={handleSubmit}>
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

export default Modal;
