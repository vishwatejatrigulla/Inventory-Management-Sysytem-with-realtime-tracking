import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';

const SalesByCollections = () => {
  const host = 'http://localhost:3001';
  const [salesData, setSalesData] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSalesByCollections();
  }, []);

  const fetchSalesByCollections = async () => {
    try {
      const res = await fetch(`${host}/api/v1/analytics/sales-by-collections`);
      const data = await res.json();
      setSalesData(data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching sales by collections:', error);
    }
  };

  const renderSalesData = () => {
    if (loading) {
      return <p>Loading...</p>;
    } else {
      return (
        <div className='text-lg'>
          <h2 className='text-xl font-semibold mb-4'>Sales by Collections</h2>
          {Object.entries(salesData.collectionSalesData).map(([collectionId, collectionData]) => (
            <div key={collectionId} className="border rounded p-6 mb-4 grid grid-cols-5">
              <h3 className=' col-span-2 text-lg font-semibold'>{collectionData.collectionName}</h3>
              <div className="col-span-2 flex flex-col mt-2">
                <p>Total Items: {collectionData.totalItems}</p>
                <p>Total Quantity Sold: {collectionData.totalQuantitySold}</p>
              </div>
              <div className="col-span-1 flex flex-col justify-center items-center mt-2">
                <img src={collectionData.image} alt={collectionData.collectionName} className="w-24 h-24" />
                <p className='text-center mt-2'>Total Revenue Generated: ${collectionData.totalRevenueGenerated.toFixed(2)}</p>
              </div>
            </div>
          ))}
          {salesData.bestSellingCollection && (
            <div className="border rounded p-6 mt-4">
              <h3 className='text-lg font-semibold'>Best Selling Collection: <span className='text-xl font-bold'>{salesData.bestSellingCollection}</span> </h3>
             
              <p>Total Revenue Generated: ${salesData.maxRevenue.toFixed(2)}</p>
            </div>
          )}
        </div>
      );
    }
  };

  return (
    <div className='h-full w-full'>
      
      <div className='p-6'>
        {renderSalesData()}
      </div>
    </div>
  );
}

export default SalesByCollections;
