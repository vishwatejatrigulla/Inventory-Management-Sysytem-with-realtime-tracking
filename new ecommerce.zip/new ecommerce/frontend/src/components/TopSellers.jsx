import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';

const TopSellers = () => {
  const host = 'http://localhost:3001';
  const [topSellingItems, setTopSellingItems] = useState([]);

  useEffect(() => {
    fetchTopSellingItems();
  }, []);

  const fetchTopSellingItems = async () => {
    try {
      const res = await fetch(`${host}/api/v1/analytics/top-selling-items`);
      const data = await res.json();
      setTopSellingItems(data.top_selling_items);
      console.log(data);
    } catch (error) {
      console.error('Error fetching top selling items:', error);
    }
  };

  return (
    <div className='h-full w-full'>
      
      <div className='p-6'>
        <h2 className='text-xl font-semibold mb-4'>Top Selling Items</h2>
        <div className='max-h-[69vh] overflow-y-scroll pr-4 w-full'>
            {topSellingItems.map((item, index) => (
            <div key={index} className='mb-4 border rounded-lg p-4'>
                <div className='flex items-center justify-between mb-2'>
                <span className='font-semibold'>{index + 1}</span>
                <span className='text-sm text-gray-500'>{item.brand}</span>
                </div>
                <div className='flex items-center'>
                <img src={item.image} alt={item.name} className='w-20 h-20 object-cover mr-4 rounded-md' />
                <div>
                    <h3 className='font-semibold'>{item.name}</h3>
                    <p className='text-gray-600'>{item.total_quantity_sold} sold | ${item.total_revenue_generated.toFixed(2)} revenue</p>
                </div>
                </div>
            </div>
            ))}
        </div>
      </div>
    </div>
  );
}

export default TopSellers;
