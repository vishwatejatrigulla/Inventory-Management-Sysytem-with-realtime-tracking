import React from 'react';
import { Link } from 'react-router-dom';

const Card = ({ title, content, image,id }) => {
 return (
    <div className="bg-white shadow-xl rounded-lg p-4 flex flex-col">
         <Link to={{ pathname: `/collections/${id}`, state: {  content } }}>
      {image && (
        <div className="relative h-48 w-full overflow-hidden rounded-lg mb-4">
          <img src={image} alt={title} className="absolute inset-0 w-full h-full object-contain" />
        </div>
      )}
      <h2 className="text-lg font-semibold mb-2">{title}</h2>
      <p className="text-gray-700">{content}</p>
      </Link>
    </div>
 );
};

export default Card;
